# ramnotice

RAM warning CLI tool for low-end Linux devices.

## Usage
ramnotice

